## [1.0.0] 2018-01-29
### Original Release
- Added Material_UI as base framework
- Added design from Material Dashboard by Creative Tim
